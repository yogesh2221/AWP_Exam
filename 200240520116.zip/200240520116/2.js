
function validation(){

var uname = document.getElementById("username").nodeValue;
var pwd = document.getElementById("password").nodeValue;

if(uname == "|| pwd == ")
{
    alert("please enter username and password")
}
else if(uname.length < 3 || uname.length >12)
{
    alert("username must be 3 to 12 character");
}
}
else if(pwd.length <5 || pwd.length >12)
{
    alert("password must be 3 to 12 character")
}
}
else{
    alert("Thank you for login");
}

}